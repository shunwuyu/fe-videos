触屏 重力感应 陀螺仪 手机区别于PC 
touchstart touchmove  touchend ? 
- 让我们的阴影 感知力度？ css border-radius 50%  
- 那么多张树懒的照片？ 
- 力度作用到照片? 
- 雪碧图 
  往右走， 往下走都是负值
  background-size: 400%;